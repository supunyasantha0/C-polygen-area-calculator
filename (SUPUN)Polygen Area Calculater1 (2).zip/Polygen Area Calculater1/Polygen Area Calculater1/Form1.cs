﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.MonthCalendar;

namespace Polygen_Area_Calculater1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int numericValue = (int)numericUpDown1.Value;
            int txtsidelen = 0;

            if (numericValue < 3)
            {
                MessageBox.Show("Polygen requires at least 3 sides.", "Verification Failure", MessageBoxButtons.OK, MessageBoxIcon.Error); return;
            }
            if (!int.TryParse(textBox1.Text, out txtsidelen) || txtsidelen < 0)
            {
                MessageBox.Show("Side lengths must be positive numbers.", "Verification Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            try
            {
                txtsidelen = int.Parse(textBox1.Text);
            }
            catch (FormatException)
            {
                MessageBox.Show("Invalid input in the text box.", "Verification Failure", MessageBoxButtons.OK, MessageBoxIcon.Error); return;
            }

            int result = numericValue * txtsidelen;
            textBox2.Text = result.ToString() + "cm";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double sideLen = double.Parse(textBox1.Text);
            int numberofSides = (int)numericUpDown1.Value;
            double area = (numberofSides * Math.Pow(sideLen, 2)) / (4 * Math.Tan(Math.PI / numberofSides));
            string roundedArea = area.ToString("0.00");
            textBox3.Text = roundedArea;

            int numericValue = (int)numericUpDown1.Value;
            int textBoxValue = 0;

            if (numericValue < 3)
            {
                MessageBox.Show("Polygen requires at least 3 sides.", "Verification Failure", MessageBoxButtons.OK, MessageBoxIcon.Error); return;
            }
            if (!int.TryParse(textBox1.Text, out textBoxValue) || textBoxValue < 0)
            {
                MessageBox.Show("Side lengths must be positive numbers.", "Verification Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            try
            {
                textBoxValue = int.Parse(textBox1.Text);
            }
            catch (FormatException)
            {
                MessageBox.Show("Invalid input in the text box.", "Verification Failure", MessageBoxButtons.OK, MessageBoxIcon.Error); return;
            }

            int numberOfSide = (int)numericUpDown1.Value;
            float sideLength = float.Parse(textBox1.Text);

            Bitmap bitmap = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            using (Graphics g = Graphics.FromImage(bitmap))
            {
                PointF[] points = CalculatePolygonVertices(numberOfSide, sideLength, pictureBox1.Width, pictureBox1.Height);
                g.DrawPolygon(Pens.Red, points);
            }

            pictureBox1.Image = bitmap;
        }

        private PointF[] CalculatePolygonVertices(int numberOfSides, float sideLength, int width, int height)
        {
            PointF[] points = new PointF[numberOfSides];
            double angleIncrement = 2 * Math.PI / numberOfSides;
            double currentAngle = -Math.PI / 2;

            float centerA = width / 2;
            float centerB = height / 2;

            for (int i = 0; i < numberOfSides; i++)
            {
                float A = (float)(sideLength * Math.Cos(currentAngle));
                float B = (float)(sideLength * Math.Sin(currentAngle));
                points[i] = new PointF(A + centerA, B + centerB);
                currentAngle += angleIncrement;
            }

            return points;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
